<!DOCTYPE html>
<html lang="en">
<head>
	<title>Settings</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<script src="../js/jquery.js"></script>
	<style>
		.p{
			margin-bottom:30px;
		
		}
		.p a{
			color:hsl(210,100%,50%);
		}
		
		img.lock{
	display: none;
	height: 34.5px;
}
.pass img{
	position: absolute;
	width: 35px;
	right: 10px;
	top: 20px;
}
.pass{
	position: relative;
}
	
	</style>
</head>
<body>
	<header>
		<p>Settings</p>
	</header>
	<p  class="p"><a href="profile.php">Back to profile</a></p>
<form method="post" action="process_settings.php">
	<ul>
		<li>
			<label>Number</label>
			<input type="tel" name="number">
		</li>
		
	<li class='pass'>
				<img src="../img/eye.png" class='eye'>
				<img src="../img/lock.png" class='lock'>
				<label>Password</label>
				<input type="password" name="password">
			</li>
	
		<li>
			<input type="submit" values="Change">
		</li>
	</ul>
	
</form>
<script>
	$(document).ready(function(){
		/*Functionalities for hiding and showing password*/
    $(".pass .eye").click(function(){
    $(".pass input").attr('type','text');
	$(this).hide();
	$(".pass .lock").show();
	})//end click

	$(".pass .lock").click(function(){
    $(".pass input").attr('type','password');
	$(this).hide();
	$(".pass .eye").show();
	})//end click
	})//end ready
	</script>
</body>
</html>