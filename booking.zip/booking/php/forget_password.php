<?php
require "db_connect.php";
$number = trim($_REQUEST['number']);
$email = trim($_REQUEST['email']);
//Checking for validity of number and email
$query = sprintf("SELECT * FROM users WHERE email='%s' AND number='%s';",mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$number));
$result = mysqli_query($conn,$query);

if(mysqli_num_rows($result) != 0){
	$rand = rand();//Using a new random variable for the password
  $encryptedPassword = openssl_encrypt($rand,'seed','lock');//encrypting the random password with openssl API in PHP
    $query_update = sprintf("UPDATE users SET password ='%s' WHERE email='%s';",$encryptedPassword,mysqli_real_escape_string($conn,$email));
    $result_update = mysqli_query($conn,$query_update);
    if($result_update){
      //If ne password is set, forward it to the user's email and redirect the user to the forget password page with success message
    	@mail($email, 'Your new password', $rand);
    	header('location:forget.php?success=Your password has been sent to your email');
    }else{
      header('location:forget.php?success=An error occured please try again later');  
    }
}else{
	header("location:error.php?from=forget.php&error=Incorrect email or Telephone number");
}
?>