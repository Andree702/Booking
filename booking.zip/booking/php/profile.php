<!DOCTYPE html>
<html lang="en">
<head>
	<title>User's profile</title>
	<meta charset="utf-8">
	<meta name='viewport' content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/profile.css">
	<script src='../js/jquery.js'></script>
</head>
<body>
	<header>
		<p> <a href="../index.php">Booking.com</a></p>
		<nav>
		<a href="settings.php">Settings</a>
		<a href="logout.php">Logout</a>
        </nav>
	</header>
	<article>
<?php
error_reporting(0);//Suppressing
if($_REQUEST['success']){
	echo "<p class='msg'>".$_REQUEST['success']."</p>";
}
require 'db_connect.php';
$query_user = sprintf('SELECT * FROM users WHERE id=%d;',mysqli_real_escape_string($conn,$_SESSION['id']));
$result_user = mysqli_query($conn,$query_user);
if($result_user){
	$row = mysqli_fetch_array($result_user);
	$name = $row['name'];
	echo '<h1 class="name">Welcome '.$name.'</h1>';
}
//New events
$query_events = sprintf("SELECT * FROM event_org;");
$result = mysqli_query($conn,$query_events);
$counter = 0;//For counting unbooked event

if(mysqli_num_rows($result) != 0){

	echo "<h2>Unbooked events appear below</h2>";
}
while($row = mysqli_fetch_array($result)){
	$id = $row["event_id"];

	//checking if one has booked this event already
	$query_booked = sprintf("SELECT * FROM books WHERE user_id=%d AND event_id2=%d;",$_SESSION["id"],$id);
	$result_booked = mysqli_query($conn,$query_booked);
	if(mysqli_num_rows($result_booked) != 0){
		continue;
	}
	$title = $row['title'];
	$location = $row['location'];
	$date = $row["date"];
	$start_time = $row['start'];
	$end_time = $row['endt'];
    $status = $row["status"];
	$description = $row["description"];
//Counting the number of people who sign up for this event
$query_books = sprintf("SELECT * FROM books WHERE id=%d;",$id);
$result_books = mysqli_query($conn,$query_books);
$number_of_books = mysqli_num_rows($result_books);

//Displaying the information retrieved from the database
echo "<div>
<h1>$title</h1>
<ul>
<li><b>Location </b>$location</li>
<li><b>Date </b>$date</li>
<li><b>Start-time </b>$start_time</li>
<li><b>End-time </b>$end_time</li>
<li><b>Details </b>$description</li>
</ul>";
//decide if this event is paused before closing reservation
if($status == 'paused'){
	echo "<a href='#' class='paused'><img src='../img/pause.png'>Event paused</a>";
}else{
echo "<a href='reserve.php?id=$id' class='green'><img src='../img/forward.png'>Book now!</a>";
}

echo "</div>";
$counter ++;
}
if($counter == 0){
echo "<h3 class='no_new'>No new events</h3>";
}
//Booked events
$query_booked1 = sprintf("SELECT * FROM event_org;");
	$result_booked1 = mysqli_query($conn,$query_booked1);

	$query_mybooks = sprintf('SELECT * FROM books WHERE user_id=%d;',$_SESSION['id']);
	$result_mybooks = mysqli_query($conn,$query_mybooks);
	if(mysqli_num_rows($result_mybooks) != 0){
		echo "<br><h2>Booked event</h2>";
	}
while($row2 = mysqli_fetch_array($result_booked1)){

	$id2 = $row2["event_id"];

	//checking if one has booked this event already
	$query_booked2 = sprintf("SELECT * FROM books WHERE user_id=%d AND event_id2=%d;",$_SESSION["id"],$id2);
	$result_booked2 = mysqli_query($conn,$query_booked2);
	if(mysqli_num_rows($result_booked2) == 0){
		continue;
	}
	$title2 = $row2['title'];
	$location2 = $row2['location'];
	$date2 = $row2["date"];
	$start_time2 = $row2['start'];
	$end_time2 = $row2['endt'];
	$description2 = $row2["description"];
//Displaying the information retrieved from the database
echo "<div>
<h1>$title2</h1>
<ul>
<li><b>Location </b>$location2</li>
<li><b>Date </b>$date2</li>
<li><b>Start-time </b>$start_time2</li>
<li><b>End-time </b>$end_time2</li>
<li><b>Details </b>$description2</li>
</ul>
<a href='cancel.php?id=$id2' class='red'><img src='../img/cancel.png'>Cancel reservation</a>
</div>";
}
?>
</article>
<script>
	$(document).ready(function(){
    $('.msg').fadeOut(900).fadeIn(900).fadeOut(800);
	})//end ready
</script>
</body>
</html>