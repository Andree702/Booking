<?php
session_start();//Start session for the code below to use
//if the session admin is not set, no permision is given to this file
if(!$_SESSION['admin']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Settings</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<style>
		.p{
			margin-bottom:30px;
		
		}
		.p a{
			color:hsl(210,100%,50%);
		}
	</style>
</head>
<body>
	<header>
		<p>Set password</p>
	</header>
	<p  class="p"><a href="admin.php">Back to Admin</a></p>
<form method="post" action="process_password.php">
	<ul>
		<li>
	<input type="password" name="password" placeholder="Enter password">
	</li>
	<li>
	<input type="submit" value="Change">
	</li>
	</ul>
</form>
</body>
</html>