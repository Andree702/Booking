<?php
require "db_connect.php";//Getting database connection file
$id = $_REQUEST['id'];
$user_id = $_SESSION['id'];
//Inserting a new booked event
$query = sprintf("INSERT INTO books(user_id,event_id2) VALUES(%d,%d);",$user_id,mysqli_real_escape_string($conn,$id));
$result = mysqli_query($conn,$query);
if($result){
header("location: profile.php?success=Operation succesful");
}else{
    header("location: error.php?error=Operation unsuccessful&from=profile.php"); //if error occures, direct the user to error page
}

?>