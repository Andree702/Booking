<?php
require "db_connect.php";//Getting database connection file
//if the session admin is not set, no permision is given to this file
if(!$_SESSION["admin"]){
	header("location:../inderx.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		li{
			list-style: none;
			background:silver;
			no repeat;
		}
		body *{
			margin:0px;
			padding:0px;
			font-family:cursive;
		}
		body{
			padding:0px;
			margin:0;px;
		}
		.p a{
			color:blue;
		}
		.p{
			margin-bottom:20px;
		}
		div{
			margin-bottom:20px;
			padding:20px;
			background:silver;
		}
	</style>
</head>
<body>
<p  class="p"><a href="admin.php">Back to Admin</a></p>
	<?php
$id = $_REQUEST["id"];
/*Combining three tables to select users data for a particular event*/

$query = sprintf("SELECT * FROM users,event_org,books WHERE users.id = books.user_id AND event_org.event_id = books.event_id2 AND event_org.event_id = %d;",$id);
$result = mysqli_query($conn,$query);
while($row = mysqli_fetch_array($result)){
	$name = htmlentities($row["name"]);
	$number = htmlentities($row["number"]);
	$email = htmlentities($row["email"]);
	$about_user = htmlentities($row["about"]);
	echo "<div>
	<ul>
	<li>$name</li>
	<li>$number</li>
	<li>$email</li>
	<li>$about_user</li>
	</ul>
	</div>";
}
?>
</body>
</html>