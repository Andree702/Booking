<?php
session_start();//starting session variable to enable this file to unset the session variable
unset($_SESSION['id']);
header("location:../index.php");//after logout direct the user to home page
?>