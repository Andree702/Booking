<!DOCTYPE html>
<html lang="en">
<head>
	<title>forget password</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<script src="../js/jquery.js"></script>
</head>
<body>
<header>
	<a href="../index.php">Booking.com</a>
</header>
<p class="p">Your new password will be sent to your email</p>
<?php
 if(isset($_REQUEST['success'])){
 	echo "<p class='msg'>".$_REQUEST['success']."</p>";
 }
	?>
<form action="forget_password.php" method="post">
<ul>
	<li>
		<input type="number" name="number" required placeholder="Telephone Number">
	</li>
	<li>
		<input type="email" name="email" required placeholder="Email">
	</li>
	<li>
		<input type="submit" value="Send">
	</li>
</ul>	
</form>
<script>
	$(document).ready(function(){
$(".msg").fadeOut().fadeIn().fadeOut(5000);//hidding and showing the succes message 
	})//end ready
</script>
</body>
</html>