<?php
require "db_connect.php";//Require database connection
if(!isset($_SESSION['admin'])){
	if(isset($_POST['password'])){
		$password =  trim($_POST['password']);
		$password = openssl_encrypt($password,'seed','lock');
		//Querying for validity of the admin password
		$query = sprintf("SELECT * FROM ad_pass WHERE pass = '%s';",mysqli_real_escape_string($conn,$password));
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result) != 0){
        $row = mysqli_fetch_array($result);
        $password  = $row['pass'];
        $_SESSION['admin'] = $password;//Saving password in session admin variable for access to admin pages
        header("location:admin.php");
		}else{
			$erro  = 'Incorrect password';
		}
	}

}else{
	header("location:admin.php");//if admin has already loged in, redirect the admin to the admin page
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<style>
		.error{
			text-align: center;
			margin-top: 80px;
			font-size: 14px;
			color: red;
			z-index: 1000;
			font-family: sans-serif;
		}
		input[type='password']{
			padding-left: 5px;
		}
		header{
			margin-top:30px;
		}
	</style>
</head>
<body>
	<header><p>Log in</p></header>
	<?php
	if($erro){
	echo "<p class='error'>$erro</p>";
	}
	?>
<form method="post" action="admin_auth.php">
	<ul>
		<li>
	<input type="password" name="password" placeholder="password">
	</li>
	<li>
	<input type="submit" value="Log in">
	</li>
	</ul>
</form>
</body>
</html>