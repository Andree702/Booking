<?php
require "db_connect.php";//Require database connection

$id = $_REQUEST['id'];
$user_id = $_SESSION['id'];
//Canceling a booked event
$query = sprintf("DELETE FROM books WHERE user_id=%d AND event_id2 = %d;",$user_id,mysqli_real_escape_string($conn,$id));
$result = mysqli_query($conn,$query);
if($result){
    header("location: profile.php?success=Operation succesful");
    }else{
        header("location: error.php?error=Operation unsuccessful&from=profile.php"); //if error occures, direct the user to error page
    }

?>