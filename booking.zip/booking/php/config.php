<?php
//Constant variables for connecting to host and database
define('HOST', 'localhost');
define('DATABASE', 'event');
define('PASSWORD', '');
define('USER', 'root');

?>