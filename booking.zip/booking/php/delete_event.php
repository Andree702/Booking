<?php
require 'db_connect.php';
//if the session admin is not set, no permision is given to this file
if(!$_SESSION['id']){
	header("location:../index.php");
}
$id = $_REQUEST['id'];
//Deleting a saved event
$query = sprintf("DELETE FROM event_org WHERE event_id=%d;",$id);
$result = mysqli_query($conn,$query);

header("location:admin.php?success=operation successful");
?>