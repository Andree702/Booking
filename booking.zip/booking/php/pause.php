<?php
require "db_connect.php";//Connection to the database
//if the session admin is not set, no permision is given to this file
if(!$_SESSION["admin"]){
header("location:../index.php");
}
//Change the status of the particular event to pause
$id = $_REQUEST["id"];
$query = sprintf("UPDATE event_org SET status='paused' WHERE event_id=%d;",mysqli_real_escape_string($conn,$id));
$result = mysqli_query($conn,$query);
header("location:admin.php?success=Operation succesful");


?>