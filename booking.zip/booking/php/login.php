<?php 
require "db_connect.php";//Requiring database connection file 
/*The logic behind the login page is, if session id is set that means the user has already loged in, therefore direct the user to the profile page
else authenticate the user*/
if(!isset($_SESSION['id'])){
	if(isset($_POST['email'])){
		$email = trim($_POST['email']);
		$password = trim($_POST['password']);
		$encryptedPassword = openssl_encrypt($password,'seed','lock');
		$query = sprintf("SELECT * FROM users WHERE email='%s' AND password = '%s';",mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$encryptedPassword));
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result) != 0){
        $row = mysqli_fetch_array($result);
        $id  = $row['id'];
        $_SESSION['id'] = $id;//Saving the user id in session to enable user to access users functionalities
        header("location:profile.php");//Directing the user to the profile page
		}else{
			$erro  = 'Incorrect email or password';//Error message to be displayed if log-in details are incorrect
		}
	}

}else{
	header("location:profile.php");//if a user has already loged in, redirect the admin to the admin page
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/forms.css">
	<script src="../js/jquery.js"></script>
	<style>
		img.lock{
	display: none;
	height: 34.5px;
}
.error{
text-align:center;
color:red;
margin-bottom:-20px;
}
.pass img{
	position: absolute;
	width: 35px;
	right: 10px;
	top: 20px;
}
.pass{
	position: relative;
}
	</style>	
</head>
<body>
	<header>
	<a href="../index.php">Booking.com</a>
</header>	
<?php
	if(isset($erro)){
	echo "<p class='error'>$erro</p>";
	}else{
		echo '';
	}
	?>
	<article>
<form action="login.php" method="post">
<ul>
	<li>
		<label>Email</label>
		<input type="email" name="email">
	</li>
	<li class='pass'>
				<img src="../img/eye.png" class='eye'>
				<img src="../img/lock.png" class='lock'>
				<label>Password</label>
				<input type="password" name="password">
			</li>
	<li>
		<input type="submit" value="Log in">
	</li>
</ul>	
</form><p class='forget'><a href="forget.php">Forget password?</a></p>
</article>
<script>
	$(document).ready(function(){
		/*Functionality for showing and hiding password */
    $(".pass .eye").click(function(){
    $(".pass input").attr('type','text');
	$(this).hide();
	$(".pass .lock").show();
	})//end click

	$(".pass .lock").click(function(){
    $(".pass input").attr('type','password');
	$(this).hide();
	$(".pass .eye").show();
	})//end click
	})//end ready
</script>
</body>
</html>